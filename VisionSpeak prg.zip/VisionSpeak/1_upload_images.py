import os
# This line turns off the annoying 'oneDNN' warning!
os.environ['TF_ENABLE_ONEDNN_OPTS'] = '0' 

import cv2
import mediapipe as mp
import csv

print("Loading AI Model (This takes a few seconds)...")

# --- Initialize MediaPipe ---
mp_hands = mp.solutions.hands
hands = mp_hands.Hands(static_image_mode=True, max_num_hands=2, min_detection_confidence=0.5)

dataset_folder = "dataset"
csv_file = "gesture_dataset.csv"

# Create CSV header if file doesn't exist
if not os.path.exists(csv_file):
    with open(csv_file, mode='w', newline='') as f:
        writer = csv.writer(f)
        header = ["label"] + [f"coord_{i}" for i in range(84)] 
        writer.writerow(header)

print(f"\nScanning folder: '{dataset_folder}' for images...")

total_processed = 0

# Check if the dataset folder actually exists
if not os.path.exists(dataset_folder):
    print(f"❌ ERROR: I cannot find a folder named '{dataset_folder}'!")
    print("Please create a folder named 'dataset' and put your image folders inside it.")
    exit()

# Loop through every folder in the 'dataset' directory
for label in os.listdir(dataset_folder):
    label_path = os.path.join(dataset_folder, label)
    
    if os.path.isdir(label_path):
        print(f"Processing gesture: {label}...")
        count = 0
        
        for image_name in os.listdir(label_path):
            image_path = os.path.join(label_path, image_name)
            frame = cv2.imread(image_path)
            
            if frame is None:
                continue 
                
            rgb_frame = cv2.cvtColor(frame, cv2.COLOR_BGR2RGB)
            results = hands.process(rgb_frame)
            row_data = [0.0] * 84 
            
            if results.multi_hand_landmarks:
                for i, hand_landmarks in enumerate(results.multi_hand_landmarks):
                    if i >= 2: break
                    
                    wrist_x = hand_landmarks.landmark[0].x
                    wrist_y = hand_landmarks.landmark[0].y
                    
                    for j, lm in enumerate(hand_landmarks.landmark):
                        row_data[(i * 42) + (j * 2)] = lm.x - wrist_x
                        row_data[(i * 42) + (j * 2) + 1] = lm.y - wrist_y
                        
                with open(csv_file, mode='a', newline='') as f:
                    writer = csv.writer(f)
                    writer.writerow([label] + row_data)
                
                count += 1
                total_processed += 1
                
        print(f" -> Successfully extracted {count} samples for '{label}'.")

if total_processed == 0:
    print("\n⚠️ WARNING: 0 images were processed.")
    print("Make sure you have images inside your folders (like dataset/ASL_A/image1.jpg)")
else:
    print(f"\n✅ DONE! Extracted {total_processed} hand gestures into '{csv_file}'.")
    print("Run '2_train_model.py' next.")