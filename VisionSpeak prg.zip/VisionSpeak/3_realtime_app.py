import cv2
import mediapipe as mp
import numpy as np
import tensorflow as tf
import pickle
import pyttsx3
import threading

def speak_sentence(text):
    """ Safe audio function """
    try:
        engine = pyttsx3.init()
        engine.setProperty('rate', 130)
        engine.say(", " + text) 
        engine.runAndWait()
    except Exception as e:
        print(f"Audio Error: {e}")

model = tf.keras.models.load_model("vision_speak_model.h5")
with open("label_encoder.pkl", "rb") as f:
    encoder = pickle.load(f)

mp_hands = mp.solutions.hands
hands = mp_hands.Hands(max_num_hands=2, min_detection_confidence=0.7)
mp_draw = mp.solutions.drawing_utils

cap = cv2.VideoCapture(0)

last_word = ""
word_stable_frames = 0
STABILITY_THRESHOLD = 15 
sentence = [] 
last_added_word = "" 

print("\n" + "="*30)
print("       BILINGUAL CONTROLS")
print("="*30)
print("1. AI automatically detects ASL or ISL.")
print("2. It will speak automatically.")
print("3. Press SPACE to repeat full sentence.")
print("4. Press 'c' to Clear sentence.")
print("5. Press 'q' to Quit.")
print("="*30 + "\n")

while cap.isOpened():
    success, frame = cap.read()
    if not success: break
    frame = cv2.flip(frame, 1)
    h, w, c = frame.shape
    rgb_frame = cv2.cvtColor(frame, cv2.COLOR_BGR2RGB)
    
    results = hands.process(rgb_frame)
    current_word = ""
    confidence = 0.0
    row_data = [0.0] * 84 
    detected_language = "Detecting..."

    if results.multi_hand_landmarks:
        for i, hand_landmarks in enumerate(results.multi_hand_landmarks):
            if i >= 2: break
            mp_draw.draw_landmarks(frame, hand_landmarks, mp_hands.HAND_CONNECTIONS)
            
            wrist_x = hand_landmarks.landmark[0].x
            wrist_y = hand_landmarks.landmark[0].y
            
            for j, lm in enumerate(hand_landmarks.landmark):
                row_data[(i * 42) + (j * 2)] = lm.x - wrist_x
                row_data[(i * 42) + (j * 2) + 1] = lm.y - wrist_y
        
        prediction = model.predict(np.array([row_data]), verbose=0)[0]
        max_idx = np.argmax(prediction)
        confidence = prediction[max_idx]
        
        if confidence > 0.70:
            raw_label = encoder.inverse_transform([max_idx])[0]
            
            # --- SMART BILINGUAL FILTER ---
            # Separates the language tag (ASL/ISL) from the actual word
            if raw_label.startswith("ASL_"):
                detected_language = "American Sign Language (ASL)"
                current_word = raw_label.replace("ASL_", "")
            elif raw_label.startswith("ISL_"):
                detected_language = "Indian Sign Language (ISL)"
                current_word = raw_label.replace("ISL_", "")
            else:
                detected_language = "Custom Sign"
                current_word = raw_label
            
            # Display what language is being used at the top!
            cv2.putText(frame, f"Language: {detected_language}", (10, 30), 
                        cv2.FONT_HERSHEY_SIMPLEX, 0.6, (255, 255, 0), 2)
            
            cv2.putText(frame, f"Sign: {current_word} ({confidence*100:.1f}%)", 
                        (10, 60), cv2.FONT_HERSHEY_SIMPLEX, 0.8, (0, 255, 0), 2)
                        
            if current_word == last_word:
                word_stable_frames += 1
            else:
                word_stable_frames = 0
                last_word = current_word
                
            if word_stable_frames > STABILITY_THRESHOLD:
                if current_word != last_added_word: 
                    sentence.append(current_word)
                    last_added_word = current_word
                    print(f"[{detected_language}] Added Sign: {current_word}")
                    threading.Thread(target=speak_sentence, args=(current_word,)).start()
                word_stable_frames = -20 

    # --- UI: Display Sentence ---
    display_text = " ".join(sentence[-6:]) 
    cv2.rectangle(frame, (0, h - 50), (w, h), (0, 0, 0), -1)
    cv2.putText(frame, f"Sentence: {display_text}", (10, h - 15), 
                cv2.FONT_HERSHEY_SIMPLEX, 0.6, (255, 255, 255), 2)

    cv2.imshow("VisionSpeak - Bilingual Translation", frame)
    
    key = cv2.waitKey(1) & 0xFF
    if key == ord('q'): 
        break
    elif key == ord(' ') or key == 13: 
        if len(sentence) > 0:
            full_sentence = " ".join(sentence)
            print(f"\n--> SPEAKING FULL SENTENCE: '{full_sentence}'")
            threading.Thread(target=speak_sentence, args=(full_sentence,)).start()
            sentence = [] 
            last_added_word = ""
    elif key == ord('c'): 
        sentence = []
        last_added_word = ""
        print("\nSentence cleared.")

cap.release()
cv2.destroyAllWindows()